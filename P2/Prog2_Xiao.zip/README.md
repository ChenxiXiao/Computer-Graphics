Name: Cici Xiao
Program 2 

I built towards my final project. I added the part of the campus and the sun. In the future, I will integrate the entire campus rendered by mtl file and illumination. 


Information:
Press A - Go left 
Press D - Go right 
Press W - Go up 
Press S - Go down 

Expected view is attached (see expected.jpg)
